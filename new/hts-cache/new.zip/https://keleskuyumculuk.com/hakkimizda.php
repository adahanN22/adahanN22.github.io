<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KELEŞ KUYUMCULUK</title>
    <meta name="description" content="Konya'da Sarraflar Caddesinde 2008 Yılından Beri Toptan ve Perakende Kuyumculuk Faaliyetlerimize Devam Etmekteyiz.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="/style.css" rel="stylesheet">

    <meta property="og:title" content="KELEŞ KUYUMCULUK">
    <meta property="og:description" content="Konya'da Sarraflar Caddesinde 2008 Yılından Beri Toptan ve Perakende Kuyumculuk Faaliyetlerimize Devam Etmekteyiz.">
    <meta property="og:image" content="https://keleskuyumculuk.com/og-image-min.jpg">
    <meta property="og:url" content="https://keleskuyumculuk.com">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="og:site_name" content="KELEŞ KUYUMCULUK">
    <meta name="twitter:image:alt" content="KELEŞ KUYUMCULUK">
    <meta name="yandex-verification" content="146452ccaa8133a4" />

    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-YZBWLM6RZ9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-YZBWLM6RZ9');
</script>


</head>
<body>

<div class="header">
<div class="container">
    <div class="row">
        <div class="col-md-4 text-start">
            <img src="/uploads/logo-min.png" alt="Keleş Kuyumculuk Logo" class="img-fluid logo"/>
        </div>
        <div class="col-md-8 my-auto text-end py-2">
            <a href="tel:0 332 352 52 35" class="btn iconbtn "><span><i class="fa fa-phone"></i></span> 0 332 352 52 35</a>
        </div>
    </div>
</div>
</div>


<nav class="navbar navbar-expand-lg">
<div class="container-fluid">
    <a class="navbar-brand d-block d-lg-none" href="/">KELEŞ KUYUMCULUK</a>
    <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#toggle" aria-controls="toggle" aria-expanded="false" aria-label="toggle">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-center" id="toggle">
        <ul class="navbar-nav mb-2 mb-lg-0">
            <li class="nav-item"><a class="nav-link" aria-current="page" href="/">Ana Sayfa</a></li><li class="nav-item"><a class="nav-link active" aria-current="page" href="/hakkimizda">Hakkımızda</a></li><li class="nav-item"><a class="nav-link" aria-current="page" href="/iletisim">İletişim</a></li> 
        </ul>
    </div>
</div>
</nav>
<div class="container mt-4">
<p class="legal ">Keleş Kuyumculuk resmi internet sitesi üzerinde sunulan tüm bilgiler (altın fiyatları,anlık kur bilgileri, piyasa haberleri vb.) yalnızca bilgilendirme amaçlı olup hiç bir yatırım önerisi teşkil etmemektedir ve yatırım danımanlığı kapsamında değillerdir. Elektronik ortam üzerinden her türlü canlı verinin iletilmesi sırasında yaşanabilecek teknik aksaklıklardan Keleş Kuyumculuk sorumlu tutulamaz.</p>
</div>

<div class="spacer"></div>

<div class=footer>
    <div class="container">
        <div class="row py-4">
            <div class="col-md-3">
                <img src="/uploads/keles-logo-min.png" alt="Keleş Kuyumculuk Logo" class="img-fluid logo"/>
                <p class="ftr-text">Konya’da Toptan ve Perakende Kuyumculuk Hizmetleri İçin Bizi Tercih Edebilirsiniz.</p>
            </div>
            <div class="col-md-5 ftr-menu text-center">
            <ul class="navbar-nav ms-auto me-auto">
                <li class="nav-item"><a class="nav-link active" href="/">ANA SAYFA <span class="sr-only">(current)</span></a></li>
                <li class="nav-item"><a class="nav-link" href="/hakkimizda.php">HAKKIMIZDA</a></li>
                <li class="nav-item"><a class="nav-link" href="/duyurular.php">DUYURULAR</a></li>
                <li class="nav-item"><a class="nav-link" href="/iletisim.php">İLETİŞİM</a></li>
            </ul>
            </div>
            <div class="col-md-4">
                <ul class="navbar-nav ms-auto me-auto ftr-iltsm">
                    <li class="nav-item ">
                    <a class="nav-link" target="_blank" href="tel:0 332 352 52 35"><i class="fa fa-phone" aria-hidden="true"></i>0 332 352 52 35</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" target="_blank" href="/cdn-cgi/l/email-protection#7113181d1618311a141d14021a0408041c12041d041a5f121e1c"><i class="fa fa-envelope" aria-hidden="true"></i><span class="__cf_email__" data-cfemail="8ae8e3e6ede3cae1efe6eff9e1fff3ffe7e9ffe6ffe1a4e9e5e7">[email&#160;protected]</span></a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" target="_blank" href="https://goo.gl/maps/8QK6oW4Huisa5UteA"><i class="fa fa-location-arrow" aria-hidden="true"></i>Sahibiata Mah.Tevfikiye Cad.No:75/A, Meram/KONYA</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>


<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>
</html>